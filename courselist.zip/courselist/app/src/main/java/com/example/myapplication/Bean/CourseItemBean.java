package com.example.myapplication.Bean;

public class CourseItemBean {
    private int rownum;
    private int columnnum;
    private String coursename;

    public int getRownum() {
        return rownum;
    }

    public void setRownum(int rownum) {
        this.rownum = rownum;
    }

    public int getColumnnum() {
        return columnnum;
    }

    public void setColumnnum(int columnnum) {
        this.columnnum = columnnum;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }
}
